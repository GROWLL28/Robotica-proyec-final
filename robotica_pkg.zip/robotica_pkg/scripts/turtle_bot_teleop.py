#!/usr/bin/env python3
import rospy
import tty
import sys
import termios
import numpy as np
import keyboard
from std_msgs.msg import String
from geometry_msgs.msg import Twist
def turtle_bot_teleop():

    pub = rospy.Publisher('turtlebot_cmdVel', Twist, queue_size=10)
    rospy.init_node('turtle_bot_teleop', anonymous=True)
    rate = rospy.Rate(10)  # 10hz

    filedescriptors = termios.tcgetattr(sys.stdin)
    tty.setcbreak(sys.stdin)
    x = 0
    
    vel = int(input("Ingrese velocidad lineal:"))
    print('Valor velocidad lineal:', vel)
    ang =int (input("Ingrese velocidad angular:"))
    print('Valor velocidad angular:', ang)
    speed = 1000
    angle = 90
    lista = [vel, ang]

    while not rospy.is_shutdown():

        message = Twist()
        message.linear.x = 0
        message.linear.y = 0
        message.linear.z = 0
        message.angular.x = 0
        message.angular.y = 0
        message.angular.z = 0
        pub.publish(message)

        x = sys.stdin.read(1)[0]
        if x == "s":
            message.linear.x = -1*vel
            message.linear.y = 0
            message.linear.z = 0
            pub.publish(message)

        elif x == "w":
            message.linear.x = vel
            message.linear.y = 0
            message.linear.z = 0
            pub.publish(message)

        elif x == "a":
            message.angular.x = 0
            message.angular.y = 0
            message.angular.z = ang
            pub.publish(message)

        elif x == "d":
            message.angular.x = 0
            message.angular.y = 0
            message.angular.z = -1*ang
            pub.publish(message)
            
        elif x == "\x1b":
        	break 

        lista.append(x)
        print("lista:", lista)
        np.savetxt('lista.txt',lista, fmt="%s")
        rospy.loginfo(message)
        rate.sleep()

if __name__ == '__main__':
    try:

        turtle_bot_teleop()
    except rospy.ROSInterruptException:
        pass
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
