#!/usr/bin/env python3
from tkinter import Tk, Frame, Button, Label, ttk
from tkinter import *
from matplotlib.figure import Figure
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import matplotlib.animation as animation
import rospy
import tty
import sys
import termios
import keyboard
from std_msgs.msg import String
from geometry_msgs.msg import Twist

xr=[]
yr=[]

def callback(msg):
	
	x = round(msg.linear.x,2)
	y = round(msg.linear.y,2)
	xr.append(x)
	yr.append(y)

def turtle_bot_interface():

	rospy.init_node('turtle_bot_interface', anonymous=True)
	rospy.Subscriber('turtlebot_position', Twist, callback)

def animate(i):
	ax.clear()
	ax.plot(xr,yr)

def guardar():
	print(nom.get())
	f=open('lista.txt','r')
	datos=f.read()
	lista_nueva=[]
	for i in datos:
		if i!='\n':
			lista_nueva.append(i)
	recorrido = []
	recorrido.append(lista_nueva[0]+lista_nueva[1])
	recorrido.append(lista_nueva[2]+lista_nueva[3])
	for j in range (2,len(lista_nueva)-2):
		recorrido.append(lista_nueva[j+2])
	print(recorrido)
	np.savetxt(nom.get()+'.txt',recorrido,fmt="%s")

def pausar():
	ani.event_source.stop()
#Creacion de ventana de interfaz
ventana = Tk()
ventana.geometry('990x550')
ventana.wm_title('Interfaz')
ventana.minsize(width=950, height=550)

#Color de la ventana
e1=Label(ventana,text="Nombre del archivo: ",bg="#50C878",fg="white" )
e1.pack(pady=5,side="left",expand=1)

nom=Entry(ventana)
nom.pack(pady=5,side="left",expand=1)

frame = Frame(ventana, bg='#D7DBDD')
frame.pack(expand=1, fill='both')

fig, ax = plt.subplots(facecolor='#FFFFFF')
plt.title("Interfaz", color='black', size=16)


canvas = FigureCanvasTkAgg(fig, master=frame)
canvas.get_tk_widget().pack(padx=5, pady=5, expand=1, fill='both')

ani=animation.FuncAnimation(fig,animate,interval=1000)
canvas.draw()

Button(frame, text="Guardar",width=15,bg="#50C878",fg="white",command=guardar).pack(pady=5,side="left",expand=1)
 
Button(frame, text="Pausar",width=15,bg="#50C878",fg="white",command=pausar).pack(pady=5,side="left",expand=1)
    
if __name__ == '__main__':
    turtle_bot_interface()
    ventana.mainloop()
